#include <simplecpp>

	char matrix[110][110];
	char string_row[110], string_column[110], string_diag1[110], string_diag2[110];


bool is_palindrome(char str[110], int length)
{
    for(int i = 0; i < length; i++)
    {
        if(str[i] != str[length - 1 - i])
            return false;
    }
    return true;
}

main_program {
	int n;

	cin >> n;
	for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			char input;

			cin >> input;
			//cout << input << " ";
			matrix[i][j] = input;
		}
		//cout << "\n";
	}

	int count = 0;

	for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			string_row[j] = matrix[i][j];
			string_column[j] = matrix[j][i];
		}

		string_diag1[i] = matrix[i][i];
		string_diag2[i] = matrix[i][n-1-i];

		count += is_palindrome(string_row, n) ? 1 : 0;
		count += is_palindrome(string_column, n) ? 1 : 0;
	}

	count += is_palindrome(string_diag1, n) ? 1 : 0;
	count += is_palindrome(string_diag2, n) ? 1 : 0;

	cout << count << endl;
}
